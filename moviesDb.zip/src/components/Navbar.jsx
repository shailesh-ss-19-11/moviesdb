import React from "react";
import { Link } from "react-router-dom";

// state lifting up
// redux toolkit
const Navbar = ({ handleChange }) => {
  return (
    <div className="w-100 bg-dark">
      <div className="container">
        <div className="row align-items-center ">
          <div className="col-4">
            <h1 className="text-white">Movies DB</h1>
          </div>
          <div className="col-8">
            <div className="d-flex gap-4 justify-content-center align-items-center">
              <Link className="text-decoration-none">
                <h5 className="text-light m-0">Home</h5>
              </Link>
              <Link className="text-decoration-none">
                <h5 className="text-light m-0">Bollywood</h5>
              </Link>
              <Link className="text-decoration-none">
                <h5 className="text-light m-0">Hollywood</h5>
              </Link>
              <Link className="text-decoration-none">
                <h5 className="text-light m-0">Web Series</h5>
              </Link>
              <Link className="text-decoration-none">
                <h5 className="text-light m-0">18+</h5>
              </Link>
              <div className="input-group w-25">
                <input
                  type="text"
                  className="form-control"
                  placeholder="Search"
                  onChange={handleChange}
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
