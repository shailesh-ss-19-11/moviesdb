import React, { useEffect, useMemo, useState } from "react";
import Card from "../components/Card";
import { moviesArray } from "../../constant";
const Home = ({ searchInput = "" }) => {
  const [moviesData, setmoviesData] = useState(moviesArray);
  const [currentPage, setcurrentPage] = useState(1);

  const filteredData = useMemo(() => {
    if (searchInput.trim() === "") {
      return moviesData;
    }
    const newFilteredData = moviesData.filter((movie) =>
      movie.movieName.toLowerCase().includes(searchInput.toLowerCase())
    );
    return newFilteredData;
  }, [searchInput]);

  const perPageItems = 8;
  const totalPages = Math.ceil(moviesData.length / perPageItems);
  const startIndex = (currentPage - 1) * perPageItems;
  const endIndex = startIndex + perPageItems;
  const renderItems = filteredData.slice(startIndex, endIndex);

  return (
    <div className="row mt-3 justify-content-center">
      {renderItems && renderItems.length > 0 ? (
        renderItems.map((movie, index) => {
          return (
            <div className="col-auto" key={index}>
              <Card movie={movie} />
            </div>
          );
        })
      ) : (
        <p>No movies found</p>
      )}
      <div className="d-flex justify-content-center align-items-center gap-2">
        {[...Array(totalPages)].map((_, index) => {
          return (
            <button
              onClick={() => setcurrentPage(index + 1)}
              className="btn btn-md btn-primary btn-rounded border"
            >
              {index + 1}
            </button>
          );
        })}
      </div>
    </div>
  );
};

export default Home;
