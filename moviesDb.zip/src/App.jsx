import { useState } from "react";
import "./App.css";
import Navbar from "./components/Navbar";
import Home from "./Home/Home";

function App() {
  const [searchInput, setsearchInput] = useState("");

  const handleChange = (e) => {
    setsearchInput(e.target.value);
  };

  return (
    <div className=" ">
      <Navbar handleChange={handleChange} />
      <div className="container">
        <Home searchInput={searchInput} />
      </div>
    </div>
  );
}

export default App;
